<?php
/**
 * WordPress 基本設定檔。
 */

// ** 資料庫設定 ** //
define( 'DB_NAME', 'ywmzzfkesa' );
define( 'DB_USER', 'ywmzzfkesa' );
define( 'DB_PASSWORD', 'g5FFbP82Jm' );
define( 'DB_HOST', 'localhost' );
define( 'DB_CHARSET', 'utf8mb4' );
define( 'DB_COLLATE', '' );

/**#@+
 * 認證唯一金鑰設定。
 */
define('AUTH_KEY',         'i7N~](M;CeAcnXIS$B1pix+OFUd-7!E{@(Rx%Gx|}[-qA%t]+x(p+`^8diDB}N-]');
define('SECURE_AUTH_KEY',  'v}/+f+=&+/C|L^b`F+p`LbERo8PSS2/u]5l%l(DrZ#nA;ID=&1enUGbK^@E9YIw8');
define('LOGGED_IN_KEY',    'qiC Y.R3CWP_/2%,d|acG~%+SiMi5Ug*JPujA.|[WU-|Z;k|u2veTkXrXC-O?qd^');
define('NONCE_KEY',        'c6bVG- e2JYPu$3w*_WV)tAO/ZloTc)IfY6>Z]08G:|H9t%x-vJH{FDk~-[N%FIl');
define('AUTH_SALT',        '5Vf~g+Wuqn7]4~1v|(z?JBpe@I89|Z-U=H:#pUd@%l9K&pgoFuUV~%&8tCu{N4!s');
define('SECURE_AUTH_SALT', 'PqtB*GAQ7wF$zx8aiBbJ8#OX+(vly_hshGl+tU?w|1JlS?NocPFw]r]>gG>f?M~o');
define('LOGGED_IN_SALT',   'js[+|@R>wIJng9f)R+=+U|Zwp@veFcADt=d:ZQYqWW9v?Lz780,QynJV+$x<1xA}');
define('NONCE_SALT',       '?IryCRrnz[mv1WrC!<|hK{a?z:QetqV1C}0X[u#=-kl$5?4Yh#xQ>:^%dyV8`X-,');

/**#@-*/

$table_prefix = 'wp_';

// 開啟 WordPress 除錯模式
define( 'WP_DEBUG', true );
define( 'WP_DEBUG_LOG', true );
define( 'WP_DEBUG_DISPLAY', false );

// 設定 WordPress 自動更新
define( 'WP_AUTO_UPDATE_CORE', true );

// 設定 WordPress 記憶體限制
define( 'WP_MEMORY_LIMIT', '256M' );

// 設定 SSL
define( 'FORCE_SSL_ADMIN', true );

/* 設定 WordPress 變數和包含的檔案。 */
if ( ! defined( 'ABSPATH' ) ) {
    define( 'ABSPATH', __DIR__ . '/' );
}

require_once ABSPATH . 'wp-settings.php'; 